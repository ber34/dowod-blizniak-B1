#include <bits/stdc++.h>
using namespace std; using ll=long long; using ld=long double;
const vector<int> ps={5,7,11,13,17,19,23,29};
struct Cell {ld mass=0,j=0,T=0,S=0,H=0,Z5=0,ZE=0;ll primes=0,twins=0;};
int main(){const ll B=5000000; vector<ll> As={10000000LL,100000000LL,1000000000LL,10000000000LL,100000000000LL,1000000000000LL}; int lim=sqrtl(6*(As.back()+B)+1);vector<bool> sieve(lim+1,true);sieve[0]=sieve[1]=false;vector<int> primes;for(int p=2;p<=lim;p++)if(sieve[p]){if(p>=5)primes.push_back(p);if((ll)p*p<=lim)for(int j=p*p;j<=lim;j+=p)sieve[j]=false;}
 cout<<"A,h,a,r,windows,primes,twins,mass,J,T,Ssmall,model,R,Z5,ZE,length_weight\n";
 for(ll A:As){ll h=sqrtl(A),K=B/h, b=K*h, maxn=6*(A+b-1)+1; ld y=powl(6*A,.49L);int Y=floorl(y),D=ceill(maxn/y);vector<int> phi(D+1),mob(D+1,1);iota(phi.begin(),phi.end(),0);mob[0]=0;for(int p=2;p<=D;p++)if(phi[p]==p){for(int j=p;j<=D;j+=p){phi[j]-=phi[j]/p;mob[j]=-mob[j];}if((ll)p*p<=D)for(ll j=(ll)p*p;j<=D;j+=(ll)p*p)mob[j]=0;}
 vector<ld> P(D+1),Q(D+1);for(int e=1;e<=D;e++){P[e]=P[e-1];Q[e]=Q[e-1];if(gcd(e,6)==1){ld f=(ld)mob[e]/phi[e];P[e]+=f;Q[e]+=f*logl(e);}}
 vector<ll> rem(b);vector<int8_t> mu(b,1);vector<uint8_t> lp(b,1),rp(b,1);vector<double> small(b,0);for(ll i=0;i<b;i++)rem[i]=6*(A+i)+1;for(int p:primes){if((ll)p*p>maxn)break;ll inv=(p%6==1?(5LL*p+1)/6:(p+1LL)/6);ll left=(inv-A%p+p)%p,right=(p-inv-A%p+p)%p;for(ll i=left;i<b;i+=p)lp[i]=0;for(ll i=right;i<b;i+=p){rp[i]=0;int e=0;while(rem[i]%p==0){rem[i]/=p;e++;}if(e>=2)mu[i]=0;else if(e==1)mu[i]=-mu[i];}}
 for(ll i=0;i<b;i++)if(rem[i]>1)mu[i]=-mu[i];
 for(int d=5;d<=Y;d++)if(mob[d]&&gcd(d,6)==1){ll inv=(d%6==1?(5LL*d+1)/6:(d+1LL)/6);ll start=(d-inv-A%d+d)%d;double w=-mob[d]*log((double)d);for(ll i=start;i<b;i+=d)if(lp[i]&&mu[i])small[i]+=w;}
 // Independent audit rows: deterministic grid plus first 12 prime left arms.
 int checked=0; for(ll i=0;i<b;i++){if((i%(max(1LL,b/10))==0)||(lp[i]&&checked<12)){if(lp[i])checked++;ll N=6*(A+i)+1;int e=ceill(N/y)-1;cerr<<A<<','<<N<<','<<Y<<','<<e<<','<<(int)lp[i]<<','<<(int)rp[i]<<','<<(int)mu[i]<<','<<setprecision(17)<<small[i]<<','<<Q[e]-logl(N)*P[e]<<'\n';}}
 vector<pair<int,int>> ar={{0,0},{3,3},{4,4},{10,10},{3730,5120}};vector<Cell> cells(ar.size());vector<ld> lens(ar.size());
 for(ll i=0;i<b;i++){ld t=(i%h+.5L)/h;for(size_t z=0;z<ar.size();z++){auto [a,r]=ar[z];ld W=1;if(a){ld t0=(ld)a/(a+r);W=expl(a*logl(t/t0)+r*logl((1-t)/(1-t0)));}lens[z]+=W;if(!lp[i])continue;ll N=6*(A+i)+1;ld wn=W*logl(N-2);auto &c=cells[z];c.mass+=wn;c.j+=wn*mu[i];c.T+=wn*(rp[i]?logl(N):0);c.S+=wn*small[i];int e=ceill(N/y)-1; c.H+=wn*mu[i]*(Q[e]-logl(N)*P[e]);c.Z5+=wn*(N%25==0);bool ze=false;for(auto it=ps.rbegin();it!=ps.rend();++it)if(N%((ll)*it**it)==0){ze=true;break;}c.ZE+=wn*ze;c.primes++;c.twins+=rp[i];}}
 for(size_t z=0;z<ar.size();z++){auto [a,r]=ar[z];auto c=cells[z];cout<<A<<','<<h<<','<<a<<','<<r<<','<<K<<','<<c.primes<<','<<c.twins<<','<<setprecision(17)<<c.mass<<','<<c.j<<','<<c.T<<','<<c.S<<','<<c.H<<','<<c.T-c.S-c.H<<','<<c.Z5<<','<<c.ZE<<','<<lens[z]<<endl;}
 }
}
