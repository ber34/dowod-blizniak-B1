from pathlib import Path
import math, hashlib
from fractions import Fraction
import pandas as pd
import sympy as sp
p=Path(__file__).parent
C=.6601618158468696
x=pd.read_csv(p/'wyniki211.csv'); sample=pd.read_csv(p/'probki211.csv',header=None,names=['A','N','Y','e','lp','rp','mu','small','model'])
assert len(x)==30 and len(sample)==133
for row in sample.itertuples():
    n=int(row.N); fac=sp.factorint(n); mu=0 if max(fac.values())>1 else (-1)**len(fac)
    assert row.mu==mu and row.lp==sp.isprime(n-2) and row.rp==sp.isprime(n)
    s= -sum(int(sp.mobius(d))*math.log(d) for d in sp.divisors(n) if d<=row.Y) if row.lp and mu else 0
    assert abs(row.small-s)<1e-10,(row,s)
# Independent explicit model for first scale (sum over e directly, sympy).
q=sample[sample.A==sample.A.min()]; emax=int(q.e.max()); terms=[(e,int(sp.mobius(e))/int(sp.totient(e))) for e in range(1,emax+1) if math.gcd(e,6)==1]
for row in q.itertuples():
    direct=math.fsum(w*math.log(e/row.N) for e,w in terms if e<=row.e)
    assert abs(row.model-direct)<1e-10
# Normalize exactly by measured effective length in n variable.
x['len']=6*x.length_weight
for k in ['T','Ssmall','R','J']: x[k+'n']=x[k]/x['len']
x['K5']=4*C*x.Z5/x['len']; x['KE']=4*C*x.ZE/x['len']; x['net5']=x.K5+x.Rn; x['netE']=x.KE+x.Rn
x['err']=(x.Ssmall+x.model+4*C*x.J-4*C*x.mass)/x['len']
x['finite_lower']=x.netE+x.err
assert (x.ZE>=x.Z5).all() and (x.finite_lower<=x.Tn+1e-9).all()
assert (x.h*x.h<=x.A).all()
assert (x.h*x.h/(x.A-1/6)<math.log(4)).all()
assert (x.groupby('A').primes.nunique()==1).all() and (x.groupby('A').twins.nunique()==1).all()
# Independently check old stage 210 total counts, accounting for truncated final window.
oldpath=p/'klasy210.csv'; old=pd.read_csv(oldpath); old=old[old.p==5].groupby('A')[['count','twin']].sum()
for row in x[x.r==0].itertuples():
    assert 0<=old.loc[row.A,'count']-row.primes<=5000000-row.h*row.windows
    assert 0<=old.loc[row.A,'twin']-row.twins<=5000000-row.h*row.windows
x.to_csv(p/'bilans211.csv',index=False)
ps=[5,7,11,13,17,19,23,29]; prod=Fraction(1); rezerwy=[]
for prime in ps:
    prod*=1-Fraction(1,prime*(prime-1)); rezerwy.append((prime,2*C*float(1-prod)))
# Infinite square-reserve bracket with an elementary tail bound over all integers.
P=math.prod(1-1/(int(q)*(int(q)-1)) for q in sp.primerange(5,1000001)); lower=2*C*(1-P); upper=2*C*(1-P*(1-1/1000000))
print('Próbki niezależne SymPy:',len(sample),'(pierwszość, faktoryzacja, mu, Ssmall): OK')
print('Bezpośrednia kontrola modelu (moduły e) na pierwszej skali:',len(q),'wierszy: OK')
print('Powtórne uruchomienie: identyczne CSV:',(p/'wyniki211.csv').read_bytes()==(p/'wyniki211_check.csv').read_bytes())
print('Zgodność liczebności z etapem 210 z uwzględnieniem odcięcia końców: OK')
print('Warunek B2<4, bilanse i dolna granica skończona: OK')
print('Badane m:',int((x[x.r==0].h*x[x.r==0].windows).sum()),'okna:',int(x[x.r==0].windows.sum()),'bliźniaki:',int(x[x.r==0].twins.sum()))
print('Rezerwy',rezerwy); print('Przybliżony przedział K_inf (ograniczenie ogona produktu):',lower,upper)
print('Liczba dodatnich K5+R:',int((x.net5>0).sum()),'z',len(x)); print('Liczba dodatnich KE+R:',int((x.netE>0).sum()),'z',len(x));print('Niepowodzenia KE+R:');print(x.loc[x.netE<=0,['A','a','r','Rn','KE','netE','err','finite_lower']].to_string(index=False))
print('Maksymalny błąd modelu na jednostkę długości',abs((x.model+4*C*x.J)/x['len']).max())
print('SHA256 wyniki211.csv',hashlib.sha256((p/'wyniki211.csv').read_bytes()).hexdigest())
