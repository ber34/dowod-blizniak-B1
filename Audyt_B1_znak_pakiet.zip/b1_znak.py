"""Bezpośredni rachunek reszty B1 na pełnych blokach X < n <= 2X.

Przykład: python b1_znak.py --min-k 10 --max-k 24 --csv b1_bloki.csv
Certyfikaty wymierne: python b1_znak.py --certify 10 11
Etap 211, przypadek graniczny: python b1_znak.py --etap211 (dodatkowo Numba).
Wymagane: Python 3.9+ i NumPy. Opcja --certify używa wyłącznie arytmetyki
całkowitej i wymiernej do wyznaczania przedziałów dla znaku.
"""

import argparse
import csv
import math
from fractions import Fraction
from functools import lru_cache

import numpy as np


ELIMINATORS = (5, 7, 11, 13, 17, 19, 23, 29)
C2 = 0.6601618158468696


def floor_ey(e, x):
    """Dokładna wartość floor(e * X**(49/100))."""
    estimate = math.floor(e * x ** 0.49)
    target = e ** 100 * x ** 49
    while estimate ** 100 > target:
        estimate -= 1
    while (estimate + 1) ** 100 <= target:
        estimate += 1
    return estimate


def prime_list(limit):
    flags = np.ones(limit + 1, dtype=bool)
    flags[:2] = False
    for p in range(2, math.isqrt(limit) + 1):
        if flags[p]:
            flags[p * p :: p] = False
    return np.flatnonzero(flags)


def moebius_phi(limit, primes):
    mu = np.ones(limit + 1, dtype=np.int8)
    phi = np.arange(limit + 1, dtype=np.int64)
    for value in primes:
        p = int(value)
        if p > limit:
            break
        mu[p::p] *= -1
        mu[p * p :: p * p] = 0
        phi[p::p] -= phi[p::p] // p
    return mu, phi


def first_congruent(first_m, p, sign, min_m):
    start = max(first_m, min_m)
    return start - first_m + (sign * pow(6, -1, p) - start) % p


def sieve_rows(first_m, count, primes):
    right = 6 * np.arange(first_m, first_m + count, dtype=np.int64) + 1
    rem = right.copy()
    mu = np.ones(count, dtype=np.int8)
    left_prime = np.ones(count, dtype=bool)
    right_prime = left_prime.copy()
    for value in primes:
        p = int(value)
        if p < 5:
            continue
        if p * p > right[-1]:
            break
        # Prawy czynnik wykreślamy z pierwszych od p**2. W mu liczymy także p.
        i = first_congruent(first_m, p, -1, first_m)
        rem[i::p] //= p
        mu[i::p] *= -1
        j = (-pow(6, -1, p * p) - first_m) % (p * p)
        mu[j::p * p] = 0
        left_prime[first_congruent(first_m, p, 1, (p*p + 6)//6)::p] = False
        right_prime[first_congruent(first_m, p, -1, (p*p + 4)//6)::p] = False
    mu[rem > 1] *= -1
    return right, mu, left_prime, right_prime


def tail_sums(values):
    out = np.empty(len(values) + 1, dtype=np.float64)
    out[-1] = 0.0
    np.cumsum(values[::-1], out=out[-2::-1])
    return out


def discrepancy(x, right, signed, moduli, mob, phi):
    # W sumie po e nie korzystamy z pierwszości prawego ramienia ani z T.
    signed_log = signed * np.log(right / x)
    suffix, suffix_log = tail_sums(signed), tail_sums(signed_log)
    pieces = [[], [], []]
    model = []
    root = math.isqrt(x)
    for e, cut, offset in moduli:
        c = math.log(e / x)
        expected = (c * suffix[cut] - suffix_log[cut]) / int(phi[e])
        model.append(int(mob[e]) * expected)
        if e == 1:
            continue  # Delta_1 = 0 dokładnie.
        actual = c * np.sum(signed[offset::e]) - np.sum(signed_log[offset::e])
        band = 0 if e**4 <= x else (1 if e <= root else 2)
        pieces[band].append(int(mob[e]) * (actual - expected))
    return [math.fsum(v) for v in pieces], math.fsum(model)


def block(k):
    x = 1 << k
    first = (x + 1) // 6 + 1
    last = (2 * x + 1) // 6
    count = last - first + 1
    top = 6 * last + 1
    # Prosty ścisły majorant, gdyż floor(y) <= y.
    y_floor = floor_ey(1, x)
    limit = max(y_floor, top // y_floor + 1)
    primes = prime_list(max(limit, math.isqrt(top)))
    mob, phi = moebius_phi(limit, primes)
    right, right_mu, lp, rp = sieve_rows(first, count, primes)
    weights = lp * np.log(right - 2)
    good = np.ones(count, dtype=bool)
    for p in ELIMINATORS:
        good &= (right % p != 0)
    small = np.zeros(count)
    for d in range(5, y_floor + 1):
        if mob[d] and math.gcd(d, 6) == 1:
            i = (-pow(6, -1, d) - first) % d
            small[i::d] -= int(mob[d]) * math.log(d)
    moduli = []
    for e in range(1, limit + 1):
        if not mob[e] or math.gcd(e, 6) != 1:
            continue
        z = floor_ey(e, x)
        cut = max(0, (z - 1) // 6 + 1 - first)
        if cut >= count:
            break
        offset = cut + (-pow(6, -1, e) - first - cut) % e if e > 1 else cut
        moduli.append((e, cut, offset))
    for group, mask in (("przechodza", good), ("trafione", ~good)):
        w = weights * mask
        signed = w * right_mu
        bands, h = discrepancy(x, right, signed, moduli, mob, phi)
        residual = math.fsum(bands)
        # Kontrola po wyznaczeniu reszty z modułów.
        s = float(np.sum(w * (right_mu != 0) * small))
        t = float(np.sum(w * rp * np.log(right)))
        defect = (s + h + residual - t) / x
        if abs(defect) >= 2e-9:
            raise ArithmeticError((k, group, defect))
        yield dict(k=k, X=x, grupa=group, lewe=int(np.sum(lp & mask)),
                   blizniaki=int(np.sum(lp & rp & mask)), masa_X=w.sum()/x,
                   J_X=signed.sum()/x, S_X=s/x, H_X=h/x, T_X=t/x,
                   R_X=residual/x, R_do_czwartej_X=bands[0]/x,
                   R_do_pierwiastka_X=bands[1]/x, R_powyzej_pierwiastka_X=bands[2]/x,
                   kontrola_X=defect)


def trial_factors(n):
    primes = []
    divisor = 2
    while divisor * divisor <= n:
        while n % divisor == 0:
            n //= divisor
            primes.append(divisor)
        divisor += 1 if divisor == 2 else 2
    if n > 1:
        primes.append(n)
    return primes


def mu_factors(primes):
    return 0 if len(primes) != len(set(primes)) else (-1) ** len(primes)


GRID = 10**12


def log_series(z):
    n_terms = 16
    power = z
    partial = Fraction(0)
    for j in range(n_terms):
        partial += 2 * power / (2 * j + 1)
        power *= z * z
    return partial, partial + 2 * power / ((2 * n_terms + 1) * (1 - z*z))


@lru_cache(maxsize=None)
def log_bounds(n):
    """Końce całkowite przedziału GRID*log(n), szeregiem arctanh."""
    b = n.bit_length() - 1
    t = 1 << b
    log2lo, log2hi = log_series(Fraction(1, 3))
    lo, hi = log_series(Fraction(n-t, n+t))
    return math.floor(GRID * (b*log2lo + lo)), math.ceil(GRID * (b*log2hi + hi))


def certificate(k):
    # Niezależny od obliczenia wektorowego test po wszystkich (p,e).
    x = 1 << k
    data = []
    for n in range(x+1, 2*x+1):
        if n % 6 != 5 or trial_factors(n) != [n]:
            continue
        right = n + 2
        sign = mu_factors(trial_factors(right))
        if sign:
            data.append((right, right**100, sign, log_bounds(n), log_bounds(right)))
    lower, upper = Fraction(0), Fraction(0)
    for e in range(2, (2*x+2)//floor_ey(1,x)+2):
        factors = trial_factors(e)
        mu_e = mu_factors(factors)
        if not mu_e or math.gcd(6,e) != 1:
            continue
        phi = math.prod(p-1 for p in factors)  # e bezkwadratowe
        log_e = log_bounds(e)
        cutoff = e**100 * x**49
        low, high = 0, 0
        for right, power, sign, log_n, log_right in data:
            if power <= cutoff:
                continue
            # log(e/N)<0 i log(n)>0, dlatego końce iloczynu są jawne.
            left = log_n[1] * (log_e[0] - log_right[1])
            right_bound = log_n[0] * (log_e[1] - log_right[0])
            coeff = mu_e * sign * (phi * (right % e == 0) - 1)
            low += min(coeff * left, coeff * right_bound)
            high += max(coeff * left, coeff * right_bound)
        lower += Fraction(low, phi)
        upper += Fraction(high, phi)
    factor = x * GRID * GRID
    # Prezentacja z zaokrągleniem na zewnątrz do wielokrotności 10^(-9).
    return math.floor(lower * 10**9 / factor), math.ceil(upper * 10**9 / factor)


def strict_divisor_limit(n, x):
    estimate = int(n / x**0.49)
    bound = n**100
    scale = x**49
    while estimate**100 * scale >= bound:
        estimate -= 1
    while (estimate + 1)**100 * scale < bound:
        estimate += 1
    return estimate


def local_sums(first, x, signed, signed_log, suffix, suffix_log, mob, phi,
               cuts, squarefree_weight, y_floor):
    # Ta pętla jest kompilowana przez Numba w opcji --etap211.
    count = len(signed)
    model = np.zeros(len(cuts))
    centered = np.zeros(len(cuts))
    small = np.zeros(y_floor + 1)
    for e in range(1, len(cuts)):
        if mob[e] == 0 or e % 2 == 0 or e % 3 == 0:
            continue
        inv = (5 * e + 1)//6 if e % 6 == 1 else (e + 1)//6
        base = (-inv - first) % e
        cut = cuts[e]
        offset = cut + (base - cut) % e
        c = math.log(e / x)
        model[e] = mob[e] * (c * suffix[cut] - suffix_log[cut]) / phi[e]
        if e != 1:
            actual = 0.0
            for i in range(offset, count, e):
                actual += c * signed[i] - signed_log[i]
            centered[e] = mob[e] * actual - model[e]
        if 1 < e <= y_floor:
            mass = 0.0
            for i in range(base, count, e):
                mass += squarefree_weight[i]
            small[e] = -mob[e] * math.log(e) * mass
    return centered, model, small


def power_cut(x, numerator, denominator):
    bound = x**numerator
    root = int(x ** (numerator/denominator))
    while root**denominator > bound:
        root -= 1
    while (root+1)**denominator <= bound:
        root += 1
    return root


def local_weight_result(first, right, right_mu, lp, rp, hit_square, w,
                        mob, phi, cuts, compiled):
    x = 6 * first
    length = 6 * w.sum()
    weights = w * np.log(right - 2) * lp
    signed = weights * right_mu
    signed_log = signed * np.log1p((right - x) / x)
    sqfree = weights * (right_mu != 0)
    terms, models, smalls = compiled(
        first, x, signed, signed_log, tail_sums(signed), tail_sums(signed_log),
        mob, phi, cuts, sqfree, floor_ey(1, x))
    s, model_sum, residual = smalls.sum(), models.sum(), terms.sum()
    t_total = np.sum(weights * rp * np.log(right))
    if abs((s + model_sum + residual - t_total) / length) > 2e-9:
        raise ArithmeticError("Niezgodność T = S + H + R w etapie 211.")
    k_e = 4*C2*np.sum(weights * hit_square) / length
    eps = (s + model_sum + 4*C2*(signed.sum() - weights.sum())) / length
    g = k_e + residual/length
    result = dict(D_w=length, R=residual/length, rezerwa=k_e, G=g,
                  epsilon=eps, dolna=g+eps, T=t_total/length,
                  blad_tozsamosci=(s+model_sum+residual-t_total)/length)
    edges = [power_cut(x,k,100) for k in (25,30,35,40,45,49,50)]
    labels = ("do_025","025_030","030_035","035_040","040_045",
              "045_049","049_050","powyzej_050")
    for label, left, end in zip(labels, [0]+edges, edges+[len(terms)-1]):
        result[label] = terms[left+1:end+1].sum()/length
    result["025_050"] = terms[edges[0]+1:edges[-1]+1].sum()/length
    return result


def stage211(filename):
    from numba import njit

    first = 10**12
    x = 6 * first
    width = 5_000_000
    h = math.isqrt(first)
    lower_n, upper_n = x + 1, x + 6 * (width - 1) + 1
    limit = strict_divisor_limit(upper_n, x)
    cuts = np.zeros(limit + 1, dtype=np.int64)
    for e in range(strict_divisor_limit(lower_n, x) + 1, limit + 1):
        cuts[e] = (floor_ey(e, x) - lower_n) // 6 + 1
    primes = prime_list(max(limit, math.isqrt(upper_n)))
    mob, phi = moebius_phi(limit, primes)
    right, right_mu, lp, rp = sieve_rows(first, width, primes)
    t = (np.arange(width) % h + 0.5) / h
    hit_square = np.zeros(width, dtype=bool)
    for q in ELIMINATORS:
        hit_square |= right % (q*q) == 0
    compiled = njit(local_sums)
    print("X", x, " e_max", limit, " lewe", lp.sum(), " blizniaki", np.sum(lp & rp))
    with open(filename, "w", encoding="utf-8", newline="") as dst:
        writer = None
        for a,r in ((0,0), (3,3), (4,4), (10,10), (3730,5120)):
            w = np.ones(width)
            if a:
                mode = a / (a + r)
                w = np.exp(a * (np.log(t) - math.log(mode)) +
                           r * (np.log1p(-t) - math.log1p(-mode)))
            stats = local_weight_result(first, right, right_mu, lp, rp, hit_square,
                                        w, mob, phi, cuts, compiled)
            row = dict(a=a, r=r, **stats)
            if writer is None:
                writer = csv.DictWriter(dst, fieldnames=row.keys())
                writer.writeheader()
            writer.writerow(row)
            print(a, r, *(f"{stats[key]:+.9f}" for key in
                   ("R", "do_025", "025_050", "powyzej_050", "G", "epsilon", "dolna")),
                  flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--min-k", type=int, default=10)
    parser.add_argument("--max-k", type=int, default=24)
    parser.add_argument("--csv")
    parser.add_argument("--certify", type=int, nargs="+")
    parser.add_argument("--etap211", action="store_true")
    args = parser.parse_args()
    if args.etap211:
        stage211(args.csv or "b1_etap211_moduly.csv")
        return
    if args.certify:
        for k in args.certify:
            print("k =", k, " R/X w przedziale", certificate(k), "/ 10^9", flush=True)
        return
    if not 4 <= args.min_k <= args.max_k:
        parser.error("Wymagane 4 <= min-k <= max-k.")
    with open(args.csv or "b1_bloki.csv", "w", encoding="utf-8", newline="") as dst:
        writer = None
        for k in range(args.min_k, args.max_k + 1):
            rows = list(block(k))
            if writer is None:
                writer = csv.DictWriter(dst, fieldnames=rows[0].keys())
                writer.writeheader()
            writer.writerows(rows)
            dst.flush()
            print(k, *(f"{sum(r[key] for r in rows):.9f}" for key in
                        ("R_X", "R_do_czwartej_X", "R_do_pierwiastka_X",
                         "R_powyzej_pierwiastka_X")), flush=True)


if __name__ == "__main__":
    main()
