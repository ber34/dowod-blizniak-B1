"""Przedziałowy certyfikat przypadku A=10^12, (a,r)=(3730,5120).

python b1_certyfikat_211.py
Wymaga NumPy, Numba i gmpy2 z GNU MPFR. Plik b1_znak.py w tym samym katalogu.
Sito i sumy fazowe są całkowite. MPFR zaokrągla użyte logarytmy, potęgi
i podstawowe operacje na zewnątrz. Końcowe nierówności są wymierne.
"""

from fractions import Fraction as F
from math import ceil, floor, isqrt

import gmpy2 as g
import numpy as np
from numba import njit

from b1_znak import (ELIMINATORS, floor_ey, moebius_phi, power_cut, prime_list,
                     sieve_rows, strict_divisor_limit)


WEIGHT_GRID = 10**9
LOG_GRID = 10**8
X = 6 * 10**12
FIRST = X // 6
WIDTH = 5_000_000
PERIOD = 1_000_000
DOWN = g.context(precision=90, round=g.RoundDown)
UP = g.context(precision=90, round=g.RoundUp)


def scaled_weight(j, ctx):
    a, r = 3730, 5120
    left = ctx.div((2*j+1)*(a+r), 2*PERIOD*a)
    right = ctx.div((2*PERIOD-2*j-1)*(a+r), 2*PERIOD*r)
    return ctx.mul(WEIGHT_GRID, ctx.mul(ctx.pow(left, a), ctx.pow(right, r)))


def weight_grid():
    # Waga rośnie do t=a/(a+r), dalej maleje. Ogony mają Q*w <= 2.
    first, past = 340_000, 505_000
    assert (2*first+1)*8850 < 2*PERIOD*3730 < (2*past+1)*8850
    assert max(scaled_weight(first-1, UP), scaled_weight(past, UP)) <= 2
    one = np.zeros(PERIOD, dtype=np.int64)
    for j in range(first, past):
        base = int(DOWN.floor(scaled_weight(j, DOWN)))
        assert scaled_weight(j, UP) <= base + 2
        one[j] = base
    assert one.min() >= 0 and one.max() <= WEIGHT_GRID
    return np.tile(one, WIDTH // PERIOD)


@njit
def hit_sums(mob, cut, signed, absolute, eligible):
    count = len(signed)
    hits = np.zeros(len(cut), dtype=np.int64)
    size = np.zeros(len(cut), dtype=np.int64)
    unweighted = np.zeros(len(cut), dtype=np.int64)
    for e in range(2, len(cut)):
        if mob[e] == 0 or e % 2 == 0 or e % 3 == 0:
            continue
        inv = (5*e+1)//6 if e % 6 == 1 else (e+1)//6
        offset = cut[e] + (-inv - FIRST - cut[e]) % e
        s, a, c = 0, 0, 0
        for i in range(offset, count, e):
            s += signed[i]
            a += absolute[i]
            c += eligible[i]
        hits[e], size[e], unweighted[e] = s, a, c
    return hits, size, unweighted


def ceil_div(a, b):
    return -((-a)//b)


def c2_interval():
    limit, grid = 100_000, 10**16
    lo = hi = grid
    for pp in prime_list(limit):
        p = int(pp)
        if p == 2:
            continue
        d = (p-1)**2
        lo, hi = lo*(d-1)//d, ceil_div(hi*(d-1), d)
    # Iloczyn po ogonie >= 1 - suma_{k>=limit} 1/k^2 >= 1 - 1/(limit-1).
    return F(lo*(limit-2), grid*(limit-1)), F(hi, grid)


def quotient(lo, hi, den_lo, den_hi):
    assert den_lo > 0 and den_hi >= den_lo and hi >= lo
    options = (lo/den_lo, lo/den_hi, hi/den_lo, hi/den_hi)
    return min(options), max(options)


def print_interval(label, iv):
    scale = 10**6
    n, m = floor(iv[0]*scale), ceil(iv[1]*scale)
    # Wydruk dwóch liczb całkowitych zachowuje zaokrąglenie na zewnątrz.
    print(label, "[", n, ",", m, "]/10^6", flush=True)


def residual_interval(totals):
    value, abs_weights, abs_counts, count_e = totals
    estimate = F(value, WEIGHT_GRID*LOG_GRID)
    error = (F(37*abs_weights, 100_000*WEIGHT_GRID)
             + F(2*900*abs_counts, WEIGHT_GRID)
             + F(count_e, WEIGHT_GRID*LOG_GRID))
    return estimate-error, estimate+error


def main():
    right_min = X+1
    right_max = X+6*(WIDTH-1)+1
    limit = strict_divisor_limit(right_max, X)
    cut = np.zeros(limit+1, dtype=np.int64)
    for e in range(strict_divisor_limit(right_min, X)+1, limit+1):
        cut[e] = (floor_ey(e, X)-right_min)//6+1
    primes = prime_list(max(limit, isqrt(right_max)))
    mob, phi = moebius_phi(limit, primes)
    right, mu_n, left_prime, right_prime = sieve_rows(FIRST, WIDTH, primes)
    weights = weight_grid()
    eligible = left_prime & (mu_n != 0)
    absolute = weights * eligible
    signed = absolute * mu_n
    # Każda suma int64 ma moduł co najwyżej WIDTH*WEIGHT_GRID < 2**63.
    tails = {int(z): (int(signed[z:].sum()), int(absolute[z:].sum()),
                      int(eligible[z:].sum())) for z in np.unique(cut)}
    hits, size, unweighted = hit_sums(mob, cut, signed, absolute, eligible)
    x_log_lo, x_log_hi = DOWN.log(X), UP.log(X)
    scale = 10**12
    delta = F(6, 10**6)
    l_lo = F(int(DOWN.floor(DOWN.mul(scale, x_log_lo))), scale) - delta
    l_hi = F(int(UP.ceil(UP.mul(scale, x_log_hi))), scale) + delta
    assert 0 < l_lo < l_hi < 30
    bands = [[0, 0, 0, 0] for _ in range(3)]
    fourth, root = power_cut(X, 1, 4), isqrt(X)
    for e in range(2, limit+1):
        sign = int(mob[e])
        if not sign or e % 2 == 0 or e % 3 == 0:
            continue
        # C_e = log(X)*(log(e)-log(X)) < 0.
        lo = DOWN.mul(x_log_hi, DOWN.sub(DOWN.log(e), x_log_hi))
        hi = UP.mul(x_log_lo, UP.sub(UP.log(e), x_log_lo))
        c = int(DOWN.floor(DOWN.mul(LOG_GRID, lo)))
        assert UP.mul(LOG_GRID, hi) <= c + 2
        total, abs_total, count_total = tails[int(cut[e])]
        divisor = int(phi[e])
        num = sign * (int(hits[e])*divisor - total)
        band = bands[0 if e <= fourth else (1 if e <= root else 2)]
        band[0] += (num*c)//divisor
        band[1] += int(size[e]) + ceil_div(abs_total, divisor)
        band[2] += int(unweighted[e]) + ceil_div(count_total, divisor)
        band[3] += 1
    # |log(n)-log(X)|, |log(N)-log(X)| < 6e-6.
    # Błąd iloczynu wraz z siatką dla C_e jest <0.00037.
    assert delta*(60+delta) + F(2,LOG_GRID) < F(37,100_000)
    res_lo, res_hi = residual_interval(list(map(sum, zip(*bands))))
    weight_sum = int(weights.sum())
    den_lo = F(6*weight_sum, WEIGHT_GRID)
    den_hi = F(6*(weight_sum+2*WIDTH), WEIGHT_GRID)
    c_lo, c_hi = c2_interval()
    square = np.zeros(WIDTH, dtype=bool)
    for p in ELIMINATORS:
        square |= right % (p*p) == 0
    zero = left_prime & square
    z_lo = F(int(weights[zero].sum()), WEIGHT_GRID)*l_lo
    z_hi = F(int(weights[zero].sum())+2*int(zero.sum()), WEIGHT_GRID)*l_hi
    r_iv = quotient(res_lo, res_hi, den_lo, den_hi)
    g_iv = quotient(res_lo+4*c_lo*z_lo, res_hi+4*c_hi*z_hi, den_lo, den_hi)
    # G + epsilon = (T - 4*C2*(M-J-Z))/D; współczynniki M-J-Z są nieujemne.
    b = left_prime.astype(np.int8) * (1 - mu_n - square.astype(np.int8))
    assert b.min() >= 0 and b.max() <= 2
    tw = left_prime & right_prime
    weighted_twins, tw_count = int(weights[tw].sum()), int(tw.sum())
    t_lo = F(weighted_twins, WEIGHT_GRID)*l_lo*l_lo
    t_hi = F(weighted_twins+2*tw_count, WEIGHT_GRID)*l_hi*l_hi
    mass = int((weights*b).sum())
    m_lo = F(mass, WEIGHT_GRID)*l_lo
    m_hi = F(mass+2*int(b.sum()), WEIGHT_GRID)*l_hi
    full = quotient(t_lo-4*c_hi*m_hi, t_hi-4*c_lo*m_lo, den_lo, den_hi)
    print("Wiersze:", WIDTH, "lewe pierwsze:", int(left_prime.sum()),
          "blizniaki:", tw_count, "e_max:", limit)
    print_interval("R/D", r_iv)
    print_interval("G", g_iv)
    print_interval("G+epsilon", full)
    for label, band in zip(("e<=X^(1/4)", "X^(1/4)<e<=sqrt(X)", "e>sqrt(X)"), bands):
        print_interval(label, quotient(*residual_interval(band), den_lo, den_hi))
    assert r_iv[1] < 0 and g_iv[1] < 0 < full[0]


if __name__ == "__main__":
    main()
